这个pytorch写的jupyter notebook用来重现频率原则。
fprinciple_brief.ipynb 把大部分细节都放在了utils.py，方便初学者快速入手。本次实验课主要以这个代码为主。

fprinciple.ipynb 有详细的代码。
f-principlr_nd.ipynb 这是高维的频率原则验证，较难上手。
example.ipynb 这里是一维实验里的任务的参考答案。

上课期间，我们将使用学校的超算（不用排队）。
课后，学校超算仍然可以使用一段时间，但需要按正常提交任务，有时需要等待。
本课程的任务普通的个人电脑也可以跑，建议安装anaconda后，创建pytorch环境。具体如何操作可以参考pytorch官网。

更详细的深度学习介绍可以参考：https://github.com/xuzhiqin1990/understanding_dl
